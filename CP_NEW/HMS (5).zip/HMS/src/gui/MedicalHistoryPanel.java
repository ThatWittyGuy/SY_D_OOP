package gui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class MedicalHistoryPanel extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public MedicalHistoryPanel() {
        setTitle("Medical History");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "Date", "Condition", "Surgeries", "Medication"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField idField = new JTextField();
        JTextField dateField = new JTextField("YYYY-MM-DD");
        JTextField conditionField = new JTextField();
        JTextField surgeriesField = new JTextField();
        JTextField medicationField = new JTextField();

        formPanel.add(new JLabel("ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Date:"));
        formPanel.add(dateField);
        formPanel.add(new JLabel("Condition:"));
        formPanel.add(conditionField);
        formPanel.add(new JLabel("Surgeries:"));
        formPanel.add(surgeriesField);
        formPanel.add(new JLabel("Medication:"));
        formPanel.add(medicationField);
        add(formPanel, BorderLayout.NORTH);

        JButton addBtn = new JButton("Add Record");
        JButton refreshBtn = new JButton("Refresh");

        JPanel btnPanel = new JPanel();
        btnPanel.add(addBtn);
        btnPanel.add(refreshBtn);
        add(btnPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement stmt = con.prepareStatement("INSERT INTO medical_history VALUES (?, ?, ?, ?, ?)")) {
                stmt.setInt(1, Integer.parseInt(idField.getText()));
                stmt.setDate(2, Date.valueOf(dateField.getText()));
                stmt.setString(3, conditionField.getText());
                stmt.setString(4, surgeriesField.getText());
                stmt.setString(5, medicationField.getText());
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Record added successfully.");
                refreshTable();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        refreshBtn.addActionListener(e -> refreshTable());

        refreshTable();
    }

    private void refreshTable() {
        model.setRowCount(0);
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM medical_history")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getDate("date"),
                        rs.getString("conditions"),
                        rs.getString("surgeries"),
                        rs.getString("medication")
                });
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
