package gui;
import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class PatientPanel extends JFrame {
    private JTextField nameField, ageField, genderField, contactField, addressField;
    private JTable table;
    private DefaultTableModel model;

    public PatientPanel() {
        setTitle("Patient Management");
        setSize(800, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Patient Details"));

        nameField = new JTextField();
        ageField = new JTextField();
        genderField = new JTextField();
        contactField = new JTextField();
        addressField = new JTextField();

        formPanel.add(new JLabel("Name:")); formPanel.add(nameField);
        formPanel.add(new JLabel("Age:")); formPanel.add(ageField);
        formPanel.add(new JLabel("Gender:")); formPanel.add(genderField);
        formPanel.add(new JLabel("Contact:")); formPanel.add(contactField);
        formPanel.add(new JLabel("Address:")); formPanel.add(addressField);

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");

        formPanel.add(addBtn);
        formPanel.add(updateBtn);

        add(formPanel, BorderLayout.NORTH);

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"ID", "Name", "Age", "Gender", "Contact", "Address"});
        table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        add(scroll, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        btnPanel.add(deleteBtn);
        add(btnPanel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> addPatient());
        updateBtn.addActionListener(e -> updatePatient());
        deleteBtn.addActionListener(e -> deletePatient());

        table.getSelectionModel().addListSelectionListener(e -> fillFormFromTable());

        fetchPatients();
        setVisible(true);
    }

    private void fetchPatients() {
        model.setRowCount(0);
        try (Connection con = DBConnection.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery("SELECT * FROM patient");
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("gender"),
                        rs.getString("contact"),
                        rs.getString("address")
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addPatient() {
        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO patient(name, age, gender, contact, address) VALUES(?,?,?,?,?)");
            ps.setString(1, nameField.getText());
            ps.setInt(2, Integer.parseInt(ageField.getText()));
            ps.setString(3, genderField.getText());
            ps.setString(4, contactField.getText());
            ps.setString(5, addressField.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Patient added!");
            fetchPatients();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void updatePatient() {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(this, "Select a patient to update");
            return;
        }

        int id = (int) model.getValueAt(selected, 0);

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("UPDATE patient SET name=?, age=?, gender=?, contact=?, address=? WHERE id=?");
            ps.setString(1, nameField.getText());
            ps.setInt(2, Integer.parseInt(ageField.getText()));
            ps.setString(3, genderField.getText());
            ps.setString(4, contactField.getText());
            ps.setString(5, addressField.getText());
            ps.setInt(6, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Patient updated!");
            fetchPatients();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void deletePatient() {
        int selected = table.getSelectedRow();
        if (selected == -1) {
            JOptionPane.showMessageDialog(this, "Select a patient to delete");
            return;
        }

        int id = (int) model.getValueAt(selected, 0);

        try (Connection con = DBConnection.getConnection()) {
            PreparedStatement ps = con.prepareStatement("DELETE FROM patient WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Patient deleted!");
            fetchPatients();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void fillFormFromTable() {
        int selected = table.getSelectedRow();
        if (selected >= 0) {
            nameField.setText(model.getValueAt(selected, 1).toString());
            ageField.setText(model.getValueAt(selected, 2).toString());
            genderField.setText(model.getValueAt(selected, 3).toString());
            contactField.setText(model.getValueAt(selected, 4).toString());
            addressField.setText(model.getValueAt(selected, 5).toString());
        }
    }
}
