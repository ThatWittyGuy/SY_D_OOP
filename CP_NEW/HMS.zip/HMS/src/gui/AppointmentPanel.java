package gui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class AppointmentPanel extends JFrame {

    private JComboBox<String> patientComboBox, doctorComboBox;
    private JTextField dateField, timeField, reasonField;
    private DefaultTableModel tableModel;
    private JTable appointmentTable;

    public AppointmentPanel() {
        setTitle("Appointment Scheduler");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        patientComboBox = new JComboBox<>();
        doctorComboBox = new JComboBox<>();
        dateField = new JTextField("YYYY-MM-DD");
        timeField = new JTextField("HH:MM:SS");
        reasonField = new JTextField();

        formPanel.add(new JLabel("Patient:"));
        formPanel.add(patientComboBox);

        formPanel.add(new JLabel("Doctor:"));
        formPanel.add(doctorComboBox);

        formPanel.add(new JLabel("Date:"));
        formPanel.add(dateField);

        formPanel.add(new JLabel("Time:"));
        formPanel.add(timeField);

        formPanel.add(new JLabel("Reason:"));
        formPanel.add(reasonField);

        JButton bookBtn = new JButton("Book Appointment");
        formPanel.add(bookBtn);

        JButton refreshBtn = new JButton("Refresh");
        formPanel.add(refreshBtn);

        add(formPanel, BorderLayout.NORTH);

        // Table setup
        tableModel = new DefaultTableModel(new String[]{"ID", "Patient", "Doctor", "Date", "Time", "Reason"}, 0);
        appointmentTable = new JTable(tableModel);
        add(new JScrollPane(appointmentTable), BorderLayout.CENTER);

        // Load data
        loadPatients();
        loadDoctors();
        loadAppointments();

        bookBtn.addActionListener(e -> bookAppointment());
        refreshBtn.addActionListener(e -> loadAppointments());
    }

    private void loadPatients() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT id, name FROM patient";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            patientComboBox.removeAllItems();
            while (rs.next()) {
                patientComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadDoctors() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT id, name FROM doctor WHERE available = TRUE";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            doctorComboBox.removeAllItems();
            while (rs.next()) {
                doctorComboBox.addItem(rs.getInt("id") + " - " + rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadAppointments() {
        tableModel.setRowCount(0);
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT a.id, p.name AS patient, d.name AS doctor, a.appointment_date, a.appointment_time, a.reason " +
                         "FROM appointment a JOIN patient p ON a.patient_id = p.id " +
                         "JOIN doctor d ON a.doctor_id = d.id";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("patient"),
                        rs.getString("doctor"),
                        rs.getDate("appointment_date"),
                        rs.getTime("appointment_time"),
                        rs.getString("reason")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void bookAppointment() {
        String patient = (String) patientComboBox.getSelectedItem();
        String doctor = (String) doctorComboBox.getSelectedItem();
        String date = dateField.getText();
        String time = timeField.getText();
        String reason = reasonField.getText();

        if (patient == null || doctor == null || date.isEmpty() || time.isEmpty() || reason.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        int patientId = Integer.parseInt(patient.split(" - ")[0]);
        int doctorId = Integer.parseInt(doctor.split(" - ")[0]);

        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO appointment (patient_id, doctor_id, appointment_date, appointment_time, reason) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, patientId);
            stmt.setInt(2, doctorId);
            stmt.setString(3, date);
            stmt.setString(4, time);
            stmt.setString(5, reason);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Appointment booked!");
                loadAppointments();
                reasonField.setText("");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
