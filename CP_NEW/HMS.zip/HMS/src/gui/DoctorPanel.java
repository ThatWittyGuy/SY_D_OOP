package gui;

import db.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DoctorPanel extends JFrame {

    private JTextField nameField, specializationField, contactField;
    private JCheckBox availableCheckBox;
    private JTable doctorTable;
    private DefaultTableModel model;

    public DoctorPanel() {
        setTitle("Doctor Management");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Layout
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20));

        panel.add(new JLabel("Name:"));
        nameField = new JTextField();
        panel.add(nameField);

        panel.add(new JLabel("Specialization:"));
        specializationField = new JTextField();
        panel.add(specializationField);

        panel.add(new JLabel("Contact:"));
        contactField = new JTextField();
        panel.add(contactField);

        panel.add(new JLabel("Available:"));
        availableCheckBox = new JCheckBox();
        panel.add(availableCheckBox);

        JButton addButton = new JButton("Add Doctor");
        panel.add(addButton);

        JButton refreshButton = new JButton("Refresh List");
        panel.add(refreshButton);

        add(panel, BorderLayout.NORTH);

        // Table
        model = new DefaultTableModel(new String[]{"ID", "Name", "Specialization", "Contact", "Available"}, 0);
        doctorTable = new JTable(model);
        add(new JScrollPane(doctorTable), BorderLayout.CENTER);

        // Button actions
        addButton.addActionListener(e -> addDoctor());
        refreshButton.addActionListener(e -> loadDoctors());

        loadDoctors();
    }

    private void addDoctor() {
        String name = nameField.getText();
        String spec = specializationField.getText();
        String contact = contactField.getText();
        boolean available = availableCheckBox.isSelected();

        if (name.isEmpty() || spec.isEmpty() || contact.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO doctor (name, specialization, contact, available) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, spec);
            stmt.setString(3, contact);
            stmt.setBoolean(4, available);

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Doctor added successfully.");
                loadDoctors();
                nameField.setText("");
                specializationField.setText("");
                contactField.setText("");
                availableCheckBox.setSelected(false);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void loadDoctors() {
        model.setRowCount(0); // Clear existing rows

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM doctor";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getString("contact"),
                        rs.getBoolean("available") ? "Yes" : "No"
                });
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
